
HOW TO USE THIS WEBSITE

1. Download and unzip the folder.
2. Upload the files to a GitHub repository.
3. Enable GitHub Pages in repository settings.
4. Your website will go live.

You can edit facts inside script.js.
