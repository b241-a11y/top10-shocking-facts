
const facts = [
"Octopuses have three hearts and blue blood.",
"Honey never spoils. Jars found in ancient tombs are still edible.",
"There are more trees on Earth than stars in the Milky Way.",
"Bananas are technically berries but strawberries are not.",
"Sharks existed before trees.",
"A day on Venus is longer than a year on Venus.",
"Your brain uses about 20% of your body's total energy.",
"Wombats produce cube-shaped poop.",
"Some turtles can breathe through their butts.",
"There are more possible chess games than atoms in the observable universe."
];

const container = document.getElementById("facts-container");

facts.forEach((fact, index)=>{
  const div = document.createElement("div");
  div.className = "fact";
  div.innerHTML = `
  <div class="number">#${index+1}</div>
  <p>${fact}</p>
  `;
  container.appendChild(div);
});
